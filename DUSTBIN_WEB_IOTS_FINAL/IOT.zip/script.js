const url = "https://script.google.com/macros/s/AKfycbxFpwQsHeIK-y7qaP07qpte_DSX2YC8PXR7FmmCKntpannXbq4qbOorDgpeK4FZf8jn/exec";

function createGauge(id, max, color) {
  return new Chart(document.getElementById(id), {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [0, max],
        backgroundColor: [color, "#0f172a"],
        borderWidth: 0
      }]
    },
    options: {
      circumference: 180,
      rotation: 270,
      cutout: "75%",
      animation: { duration: 1000 },
      plugins: { legend: { display: false } }
    }
  });
}

const tempGauge = createGauge("tempGauge", 50, "#ef4444");
const humidGauge = createGauge("humidGauge", 100, "#3b82f6");
const methaneGauge = createGauge("methaneGauge", 5, "#22c55e");
const bioGauge = createGauge("bioGauge", 100, "#facc15");
const nonbioGauge = createGauge("nonbioGauge", 100, "#a855f7");

var map = L.map('map').setView([22.57, 88.36], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

var marker;

function loadData() {

  fetch(url)
    .then(res => res.json())
    .then(data => {

      let last = data[data.length - 1];

      updateGauge(tempGauge, last.temp, 50, "tempValue", "°C");
      updateGauge(humidGauge, last.humid, 100, "humidValue", "%");
      updateGauge(methaneGauge, last.methane, 5, "methaneValue", "PPM");
      updateGauge(bioGauge, last.bio, 100, "bioValue", "%");
      updateGauge(nonbioGauge, last.nonbio, 100, "nonbioValue", "%");

      let lat = parseFloat(last.lat);
      let lng = parseFloat(last.lng);

      if(marker) map.removeLayer(marker);
      marker = L.marker([lat, lng]).addTo(map);
      map.setView([lat, lng], 16);
    });
}

function updateGauge(gauge, value, max, textId, unit) {
  gauge.data.datasets[0].data = [value, max-value];
  gauge.update();
  document.getElementById(textId).innerHTML =
      parseFloat(value).toFixed(2) + " " + unit;
}

setInterval(loadData, 15000);
loadData();